# -*- coding: utf-8 -*-
"""
Created on Sun Feb 27 19:06:33 2022

@author: sures
"""

import numpy as np
import cv2
import skimage.io as io
import skimage.exposure as ex
import pylab 
from matplotlib import pyplot as plt


cap = cv2.VideoCapture(0)

# Define the codec and create VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('vid.avi',fourcc, 20.0, (640,480))

while(cap.isOpened()):
    ret, frame = cap.read()
    if ret==True:
        out.write(frame)
        cv2.imwrite('vid.png', frame)  # save to a JPG file
        cv2.imshow('frame',frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'): break
    else: break
# Release everything if job is finished
cap.release()
out.release()
cv2.destroyAllWindows()
cv2.waitKey(1)

img = cv2.imread('vid.png',0)
color = ('b','g','r')
for i,col in enumerate(color):
    histr = cv2.calcHist([img],[i],None,[256],[0,256])
    plt.plot(histr,color = col)
    plt.xlim([0,256])
plt.show()

c = io.imread('vid.png')
ch = ex.equalize_hist(c)
io.imshow(ch)
f=pylab.figure()
f.show(plt.hist(ch.flatten(),bins=256))