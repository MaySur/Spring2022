# -*- coding: utf-8 -*-
"""
Created on Sun Feb 27 19:04:20 2022

@author: sures
"""

import numpy as np 
from matplotlib import pyplot as plt
import cv2 
import skimage.io as io
import skimage.exposure as ex
import pylab 


c = io.imread('vid.png')
#io.imshow(c)
ch = ex.equalize_hist(c) 
io.imshow(ch)
f = pylab.figure(); f.show(plt.hist(ch.flatten(), bins=256))
