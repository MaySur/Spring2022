# -*- coding: utf-8 -*-
"""
Created on Sun Feb 27 18:18:37 2022

@author: sures
"""
import numpy as np 
import cv2 
 
img = cv2.imread('messi5.jpg') 
b, g ,r = cv2.split(img)
b_img = img.copy()
b_img[:, :, 1] = 0
b_img[:, :, 2] = 0

g_img = img.copy()
g_img[:, :, 0] = 0
g_img[:, :, 2] = 0

r_img = img.copy()
r_img[:, :, 0] = 0
r_img[:, :, 1] = 0

c_img = img.copy()

c_img[:, :, 2] = 0

BBB_img = cv2.merge((b,b,b))
img = cv2.merge((b,g,r))
cv2.imshow('Blue',b_img) 
cv2.imshow('Green',g_img) 
cv2.imshow('Red',r_img) 
cv2.imshow('MERGEBBB',BBB_img) 
cv2.imshow('merge',c_img)



k = cv2.waitKey(0) 

if k == 27:        
    cv2.destroyAllWindows() 
elif k == ord('s'):  
    cv2.imwrite('blue.png',img) 
    cv2.destroyAllWindows()

